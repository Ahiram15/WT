<%@ page language="java" contentType="text/html;charset=UTF-8" %>

<html>
<head>
    <title>JSP Page</title>
</head>
<body>

<h1>Hello from JSP</h1>

<%
    String name = "Soumya";
    out.println("<h2>Welcome " + name + "</h2>");
%>

</body>
</html>