<%@ page language="java" %>

<html>
    <head>
        <title>Register</title>
        <style>
body {
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
            font-family: Arial, Helvetica, sans-serif;
        }
        .login-box {
            width: 320px;
            margin: 80px auto;
            padding: 25px;
            background-color: #ffffff;
            border-radius: 6px;
            box-shadow: 0 0 10px rgba(0,0,0,0.15);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        label {
            font-weight: bold;
            color: #555;
        }
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #539db0;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        .links {
            text-align: center;
            margin-top: 15px;
        }
        .links a {
            text-decoration: none;
            color: #0066cc;
            display: block;
            margin-top: 5px;
        }
        .links a:hover {
            text-decoration: underline;
        }
    </style>
    </head>
<body>

<h2>Register</h2>

<form action="register" method="post">
    Username: <input type="text" name="username"><br>
    Password: <input type="password" name="password"><br>
    Email: <input type="email" name="email"><br>
    <input type="submit" value="Register">
</form>

<%
    String msg = (String) request.getAttribute("msg");
    if (msg != null) {
%>
    <h3><%= msg %></h3>
<%
    }
%>

</body>
</html>